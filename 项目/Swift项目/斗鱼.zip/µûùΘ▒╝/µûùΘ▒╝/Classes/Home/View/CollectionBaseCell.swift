//
//  CollectionBaseCell.swift
//  MGDYZB
//
//  Created by ming on 16/10/26.
//  Copyright © 2016年 ming. All rights reserved.
//

import UIKit

class CollectionBaseCell: UICollectionViewCell {
    
}
