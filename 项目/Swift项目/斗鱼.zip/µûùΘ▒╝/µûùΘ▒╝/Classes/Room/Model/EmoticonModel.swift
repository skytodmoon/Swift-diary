//
//  EmoticonModel.swift
//  斗鱼
//
//  Created by 金亮齐 on 2017/8/28.
//  Copyright © 2017年 醉看红尘这场梦. All rights reserved.
//

import UIKit

// MARK: 每个表情里面的属性
class EmoticonModel {
    
    var emoticonName: String = ""
    
    init(emoticonName : String) {
        
        self.emoticonName = emoticonName
    }
}
