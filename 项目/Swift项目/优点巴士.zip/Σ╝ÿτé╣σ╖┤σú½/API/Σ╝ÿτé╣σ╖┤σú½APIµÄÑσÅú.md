# 优点巴士API接口

* 我的行程接口

http://www.youdianbus.cn/ydbus-api/api/evaluation/list_user_not_evaluated?dev_id=D781FAF8-C667-4FBA-B2FE-49E9B21F28C4&t_flag=true&token=a43acba1c90752f93e51f64364b71d9c&user_id=7c19f276d626928a611e0f58eeaddc09

* 我的订单

http://www.youdianbus.cn/ydbus-api/api/order/recent?dev_id=D781FAF8-C667-4FBA-B2FE-49E9B21F28C4&index=0&size=10&token=a43acba1c90752f93e51f64364b71d9c&user_id=7c19f276d626928a611e0f58eeaddc09

* 所有线路

http://www.youdianbus.cn/ydbus-api/api/line/list_running_line?index=0&line_label=&line_type=&query_name=&size=10

* 我的线路

http://www.youdianbus.cn/ydbus-api/api/user/list_user_relevant_line?dev_id=D781FAF8-C667-4FBA-B2FE-49E9B21F28C4&t_flag=true&token=a43acba1c90752f93e51f64364b71d9c&user_id=7c19f276d626928a611e0f58eeaddc09

http://www.youdianbus.cn/ydbus-api/api/wishline/list_user_all_wish_line?dev_id=D781FAF8-C667-4FBA-B2FE-49E9B21F28C4&index=0&size=10&t_flag=true&token=a43acba1c90752f93e51f64364b71d9c&user_id=7c19f276d626928a611e0f58eeaddc09

* 首页

###班车

http://www.youdianbus.cn/ydbus-api/api/events/rotation

http://www.youdianbus.cn/ydbus-api/api/user/list_recommand_line?dev_id=D781FAF8-C667-4FBA-B2FE-49E9B21F28C4&lat=22.573748&lng=113.882210&token=a43acba1c90752f93e51f64364b71d9c&user_id=7c19f276d626928a611e0f58eeaddc09

###公交

http://www.youdianbus.cn/ydbus-busservice/api/line/list_line_detail?direction=02&line_id=02360&user=tbus

http://www.youdianbus.cn/ydbus-busservice/api/line/list_line_detail?direction=02&line_id=00725&user=tbus

http://www.youdianbus.cn/ydbus-busservice/api/line/list_line_detail?direction=01&line_id=02360&user=tbus


http://www.youdianbus.cn/ydbus-busservice/api/station/list_station_by_location?coordinates_kind=bd&cur_lat=22.57374767338604&cur_lng=113.8822104197006&user=tbus


