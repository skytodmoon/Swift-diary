//
//  ShareTool.swift
//  小日子
//
//  Created by 金亮齐 on 2017/2/27.
//  Copyright © 2017年 醉看红尘这场梦. All rights reserved.
//

import UIKit

class ShareTool: NSObject {
    
    class func shareToSina(model: ShareModel, viewController: UIViewController?)  {
        let image: UIImage = UIImage(named: "author")!
        
    }
    
    class func shareToWeChat(model: ShareModel) {
        
    }
    
    
    class func shareToWeChatFriends(model: ShareModel) {
        
    }

}
