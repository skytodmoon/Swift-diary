//
//  StartedToRemindController.m
//  斗鱼(OC)
//
//  Created by 金亮齐 on 2017/6/2.
//  Copyright © 2017年 醉看红尘这场梦. All rights reserved.
//

#import "StartedToRemindController.h"

@interface StartedToRemindController ()

@end

@implementation StartedToRemindController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"开播提醒";
    self.view.backgroundColor = [UIColor whiteColor];
}


@end
