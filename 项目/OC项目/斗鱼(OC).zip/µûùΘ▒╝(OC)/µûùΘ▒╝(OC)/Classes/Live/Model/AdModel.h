//
//  AdModel.h
//  斗鱼(OC)
//
//  Created by 金亮齐 on 2017/6/2.
//  Copyright © 2017年 醉看红尘这场梦. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdModel : NSObject

@property (nonatomic,copy) NSString *proname;

@property (nonatomic,copy) NSString *link;

@property (nonatomic,copy) NSString *srcid;

@end
