//
//  NoDataView.m
//  斗鱼(OC)
//
//  Created by 金亮齐 on 2017/6/1.
//  Copyright © 2017年 醉看红尘这场梦. All rights reserved.
//

#import "NoDataView.h"

@implementation NoDataView

+ (instancetype)noDataView {
    return [[[NSBundle mainBundle] loadNibNamed:@"NoDataView" owner:nil options:nil] lastObject];
}
@end
