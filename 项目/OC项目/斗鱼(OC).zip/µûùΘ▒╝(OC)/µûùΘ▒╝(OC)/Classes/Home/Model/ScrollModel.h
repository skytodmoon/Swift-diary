//
//  ScrollModel.h
//  斗鱼(OC)
//
//  Created by 金亮齐 on 2017/6/2.
//  Copyright © 2017年 醉看红尘这场梦. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Room.h"

@interface ScrollModel : NSObject

@property(nonatomic,copy) NSString *ID;

@property(nonatomic,copy) NSString *title;

@property(nonatomic,copy) NSString *pic_url;

@property(nonatomic,copy) NSString *tv_pic_url;

@property(nonatomic,strong) Room *room;

@end
