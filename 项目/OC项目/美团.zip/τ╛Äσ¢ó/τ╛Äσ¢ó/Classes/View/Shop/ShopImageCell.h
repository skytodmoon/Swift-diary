//
//  ShopImageCell.h
//  美团
//
//  Created by 金亮齐 on 2017/7/19.
//  Copyright © 2017年 醉看红尘这场梦. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopImageCell : UITableViewCell
@property(nonatomic, strong) UIImageView *shopImageView;
@property(nonatomic, strong) UILabel *shopNameLabel;
@property(nonatomic, strong) UILabel *shopTitleLabel;

@end
