//
//  MerAroundGroupModel.m
//  美团
//
//  Created by 金亮齐 on 2017/7/4.
//  Copyright © 2017年 醉看红尘这场梦. All rights reserved.
//

#import "MerAroundGroupModel.h"

@implementation MerAroundGroupModel


+(NSDictionary *) replacedKeyFromPropertyName{
    return @{@"rate_count":@"rate-count"};
}


@end
