//
//  AppConst.h
//  爱鲜蜂(OC)
//
//  Created by 金亮齐 on 2017/5/10.
//  Copyright © 2017年 醉看红尘这场梦. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString * const GuideViewControllerDidFinish;
extern NSString * const IsFirstOpenApp;

extern NSString * const HomeTableHeadViewHeightDidChange;
extern NSString * const HomeGoodsInventoryProblem;
extern NSString * const LFBShopCarDidRemoveProductNSNotification;
extern NSString * const LFBShopCarBuyNumberDidChangeNotification;

extern const CGFloat HomeCollectionViewCellMargin;
extern const CGFloat DefaultMargin;